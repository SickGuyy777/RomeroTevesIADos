using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ReturnState : States
{
    public override void OnEnter()
    {

    }

    public override void Update()
    {
        //Hacer funcion de que vuelve al ultimo waypoint con A* para continuar su patrullaje
    }

    public override void OnExit()
    {

    }
}
