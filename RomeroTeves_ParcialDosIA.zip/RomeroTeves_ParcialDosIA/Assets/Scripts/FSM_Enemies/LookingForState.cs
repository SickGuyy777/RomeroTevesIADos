using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LookingForState : States
{
    public override void OnEnter()
    {

    }

    public override void Update()
    {
        //Hacer funcion de que busca al jugador en su ultima posicion
    }

    public override void OnExit()
    {

    }
}
